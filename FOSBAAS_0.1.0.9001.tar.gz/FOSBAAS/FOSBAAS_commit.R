# usethis::create_package("C:/package/FOSBAAS_submit/FOSBAAS")

setwd("C:/package/FOSBAAS_submit/FOSBAAS")
# Load Functions
devtools::load_all()

scan_data <- readr::read_csv("data_raw/scan_data.csv")
wait_times_data <- readr::read_csv("data_raw/wait_times_data.csv")
wait_times_distribution_data <- readr::read_csv("data_raw/wait_times_distribution_data.csv")
freq_table_data <- readr::read_csv("data_raw/freq_table_data.csv")
customer_data <- readr::read_csv("data_raw/customer_data.csv")
demographic_data <- readr::read_csv("data_raw/demographic_data.csv")
manifest_data <- readr::read_csv("data_raw/manifest_data.csv")
perceptual_data <- readr::read_csv("data_raw/perceptual_data.csv")
season_data <- readr::read_csv("data_raw/season_data.csv")
secondary_data <- readr::read_csv("data_raw/secondary_sales_data.csv")
customer_renewals <-  readr::read_csv("data_raw/customer_renewals.csv")
aggregated_crm_data <- readr::read_csv("data_raw/aggregated_crm_data.csv")
fa_survey_data <- readr::read_csv("data_raw/fa_survey_data.csv")

# Load data

usethis::use_data(
scan_data,
wait_times_data,
wait_times_distribution_data,
freq_table_data,
customer_data,
demographic_data,
manifest_data,
perceptual_data,
season_data,
secondary_data,
customer_renewals,
aggregated_crm_data ,
fa_survey_data,
overwrite = T)

# Load documentation
devtools::document()


# install
devtools::install()

devtools::load_all()

devtools::build() #Creates Tarball

# Download package after git updated
library(devtools)
detach("package:FOSBAAS", unload = TRUE)

devtools::install_github("Justin-Watkins/FOSBAAS"
                         ,ref="master"
                         ,auth_token = "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"
)

.rs.restartR()

library(FOSBAAS)

FOSBAAS::

