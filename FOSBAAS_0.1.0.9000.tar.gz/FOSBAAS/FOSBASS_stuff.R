# Step 1:
#install.packages("devtools")
#install.packages("roxygen2")

# Step 2:


# Step 3: Put data sets into the file
devtools::document()

#scan_data <- readr::read_csv("data-raw/scan_data.csv")
#wait_times_data <- readr::read_csv("data-raw/wait_times_data.csv")
#wait_times_distribution_data <- readr::read_csv("data-raw/wait_times_distribution_data.csv")
#freq_table_data <- readr::read_csv("data-raw/freq_table_data.csv")
#freq_table_data_bin <- readr::read_csv("data-raw/freq_table_data_bin.csv")
#customer_data <- readr::read_csv("data-raw/customer_data.csv")
#demographic_data <- readr::read_csv("data-raw/demographic_data.csv")
#manifest_data <- readr::read_csv("data-raw/manifest_data.csv")
#perceptual_data <- readr::read_csv("data-raw/perceptual_data.csv")
#season_data <- readr::read_csv("data-raw/season_data.csv")
#ticket_sales_2022_2023_2024 <- readr::read_csv("data-raw/ticket_sales_2022_2023_2024.csv")
#secondary_data <- readr::read_csv("data-raw/secondary_sales_data.csv")
#customer_renewals <-  readr::read_csv("data-raw/customer_renewals.csv")
#aggregated_crm_data <- readr::read_csv("data-raw/aggregated_crm_data.csv")
#fa_survey_data <- readr::read_csv("data-raw/fa_survey_data.csv")
# Step 4:
usethis::use_data(#customer_data,
                  #demographic_data,
                  #manifest_data,
                  #perceptual_data,
                  #season_data,
                  #customer_renewals,
                  #secondary_data,
                  #wait_times_distribution_data,
                  #freq_table_data,
                  #freq_table_data_bin,
                  #fa_survey_data,
                  #aggregated_crm_data,
                  overwrite = T)


# data documentation
sinew::makeOxygen(  aggregated_crm_data , add_fields = "source")
sinew::makeOxygen(  fa_survey_data , add_fields = "source")
sinew::makeOxygen(  wait_times_distribution_data , add_fields = "source")
sinew::makeOxygen(  freq_table_data , add_fields = "source")
sinew::makeOxygen(  freq_table_data_bin , add_fields = "source")
sinew::makeOxygen(f_build_freq_table, add_fields = "source")
sinew::makeOxygen(f_get_third_degree_fit, add_fields = "source")
sinew::makeOxygen(f_simulate_distribution, add_fields = "source")

# Run after all documentation is complete
devtools::document()

usethis::use_data(#customer_data,
  #demographic_data,
  #manifest_data,
  #perceptual_data,
  #season_data,
  #customer_renewals,
  #secondary_data,
  #scan_data,
  #wait_times_distribution_data,
 # freq_table_data,
 # freq_table_data_bin,
  aggregated_crm_data,
  overwrite = T)

#sinew::makeOxygen(scan_data , add_fields = "source")
#sinew::makeOxygen(wait_times_distribution_data , add_fields = "source")
#sinew::makeOxygen(freq_table_data , add_fields = "source")
#sinew::makeOxygen(freq_table_data_bin , add_fields = "source")
# sinew::makeOxygen(  aggregated_crm_data , add_fields = "source")

devtools::build()

#======================================================================
# Test:
#======================================================================

library(FOSBAAS)

# https://tinyheero.github.io/jekyll/update/2015/07/26/making-your-first-R-package.html
# https://usethis.r-lib.org/
# https://orcid.org/0000-0003-0107-3861
# http://r-pkgs.had.co.nz/man.html

#-----------------------------------------------------------------
# Document Package
#-----------------------------------------------------------------

install.packages("roxygen2")

sinew::makeOxygen(f_build_freq_table, add_fields = "source")

# Run after all documentation is complete
devtools::document()

FOSBAAS::f_get_MMKN()

?f_get_MMKN
?f_add_zero
?f_get_time_observations
?f_define_line
?f_calc_scans

devtools::load_all()



