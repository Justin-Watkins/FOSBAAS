#' FOSBAAS: A package to help with the book "Fundamentals of Sports Business and Strategy."
#'
#' The FOSBAAS package provides dozens of functions and data sets for practicing with sports data
#'
#' @section FOSBAAS functions:
#' The FOSBAAS functions ...
#'
#' @docType package
#' @name FOSBAAS
NULL
#> NULL
